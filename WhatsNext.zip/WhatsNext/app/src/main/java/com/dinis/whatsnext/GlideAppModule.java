package com.dinis.whatsnext;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;


@GlideModule
public class GlideAppModule extends AppGlideModule {
}
