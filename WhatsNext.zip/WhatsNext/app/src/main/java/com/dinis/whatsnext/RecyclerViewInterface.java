package com.dinis.whatsnext;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
